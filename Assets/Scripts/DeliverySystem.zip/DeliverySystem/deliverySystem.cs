using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class deliverySystem : MonoBehaviour
{
    public static deliverySystem current;

    private void Awake()
    {
        current = this;
    }

    public event System.Action OnNewRound;

    public void newRound()
    {
        //listen for roundDone event
        OnNewRound();
    }

    public void OnTriggerEnter()
    {
        Debug.Log("Q was pressed");
        OnNewRound?.Invoke();
    }
}
